$(document).foundation({
	orbit: {
		animation: 'slide',
		slide_number: false,
		timer: false,
		bullets: false
	}
});